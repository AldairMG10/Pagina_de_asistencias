<?php




class Action {
	
	public static function load($action){
		// Module::$module;
		
		if(!isset($_GET['action'])){
			include "core/app/action/".$action."-action.php";
		}else{


			if(Action::isValid()){
				include "core/app/action/".$_GET['action']."-action.php";				
			}else{
				Action::Error("<b>Si tienes problemas contacta a soporte</b> Action <b>".$_GET['action']."</b>  <a href='https://accounts.google.com/v3/signin/identifier?dsh=S-83516491%3A1679711672148886&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&hd=upq.mx&sacu=1&service=mail&flowName=GlifWebSignIn&flowEntry=AddSession' target='_blank'>SOPORTE</a>");
			}



		}
	}

	
	public static function isValid(){
		$valid=false;
		if(file_exists($file = "core/app/action/".$_GET['action']."-action.php")){
			$valid = true;
		}
		return $valid;
	}

	public static function Error($message){
		print $message;
	}

	public function execute($action,$params){
		$fullpath =  "core/app/action/".$action."-action.php";
		if(file_exists($fullpath)){
			include $fullpath;
		}else{
			assert("wtf");
		}
	}

}



?>