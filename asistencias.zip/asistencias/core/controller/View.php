<?php




class View {
	
	public static function load($view){
		// Module::$module;
		if(!isset($_GET['view'])){
			include "core/app/view/".$view."-view.php";
		}else{


			if(View::isValid()){
				include "core/app/view/".$_GET['view']."-view.php";				
			}else{
				View::Error("<b>El Usuario fue eliminado,recomendamos eliminar el grupo de origen para evitar problemas</b> Puedes regresar o dar clik para dudas  <b>".$_GET['view']."</b> <a href='https://accounts.google.com/v3/signin/identifier?dsh=S-83516491%3A1679711672148886&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&hd=upq.mx&sacu=1&service=mail&flowName=GlifWebSignIn&flowEntry=AddSession' target='_blank'>DUDAS</a>");
			}
		}
	}

	public static function load_subview(){
		// Module::$module;
		if(isset($_GET['view'])!="" && isset($_GET["sb"])!=""){
			if(View::isValid()){
				$sb_src = "core/app/subview/".$_GET["view"].".".$_GET["sb"].".php";
				if(file_exists($sb_src)){
					include $sb_src;
				}else{
					View::Error("<p class='alert alert-warning'>File not found <i>".$sb_src."</i></p>");
				}
			}
		}
	}


	/**
	* @function isValid
	* @brief valida la existencia de una vista
	**/	
	public static function isValid(){
		$valid=false;
		if(isset($_GET["view"])){
			if(file_exists($file = "core/app/view/".$_GET['view']."-view.php")){
				$valid = true;
			}
		}
		return $valid;
	}

	public static function Error($message){
		print $message;
	}

}



?>

