<?php

// funcion para definir si una vista va a funcionar con las subvistas
View::load_subview();

?>