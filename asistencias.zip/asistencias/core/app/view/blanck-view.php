    <section class="">
       <?php
    date_default_timezone_set('America/Lima');
$dias = array("Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sábado");
$meses = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
 
    $fecha=date('g:ia');
?>
      <h1>Manual para el Administradores</h1>
         
         
<div class="btn-group pull-left">
  <!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
  <i class="fa fa-question-circle"></i> ¿Como funciona?
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
         <ol>
        <li>Si usted es Administrador tiene las opciones de :</li>
        <li>Agregar profesores</li>
        <li>Asignar grupos a profesores</li>
        <li>Agregar estudiantes y asignarlos a un grupo </li>
        <li>En  Opciones podra agregar los salones y crear cuentas para otros usuarios</li>
        <li>En la opcion profresores podra asignar un profesor a algun grupo</li>
        <li>En la opcion Super-Usuarios podra crear otros Administradores</li>
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Entendido</button>
      </div>
    </div>
  </div>
</div>
</div>







      <br>
      <br>
      <h1>Manual para Usuarios</h1>



         
<div class="btn-group pull-left">
  <!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter2">
  <i class="fa fa-question-circle"></i> ¿Como funciona?
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter2" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
         <ol>
        <li>Si usted es Usuario tiene las opciones de:</li>
        <li>Ver los grupos a los cuales fue asignado</li>
        <li>Realizar el pase de lista de todos sus grupos </li>
          <li>Visualizar un resumen de sus listas y reportes </li>
        <li>Realizar su pase de conducta (Solo si se lo pidieron)</li>
        <br>
        
        <div class="btn-group pull-left">
        NOTA:Tenga en cuenta que como usuario solo tendra acceso a sus grupos asignados por lo que no podra crear grupos ni registrar usuarios por lo que si tiene alguna cuestion de cambio sobre sus grupos por favor contacte con los administradores o pida que lo asignen como administrador

        </div>

      </ol>
 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Entendido</button>
      </div>
    </div>
  </div>
</div>
</div>
     
      <br>
      <br>   
   <h1>Consultar a Soporte</h1>



          

       

<a class="btn btn-primary " href="https://accounts.google.com/v3/signin/identifier?dsh=S-83516491%3A1679711672148886&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&hd=upq.mx&sacu=1&service=mail&flowName=GlifWebSignIn&flowEntry=AddSession"><i class="fa fa-cog fa-spin fa-1x fa-fw"></i> Soporte</a>

</section>