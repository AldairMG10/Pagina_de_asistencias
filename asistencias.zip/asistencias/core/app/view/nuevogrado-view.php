    <section class="container">

  <h3>REGISTRAR GRUPO</h3>
  <br>
  <form method="POST" action="./?view=agregargrado">
    <?php
      $nivel=NivelesData::getAll();
      $grado=GradData::getAll();
      $profesor=ProfesoresData::getAll();?>
  <div class="form-row">
  <div class="form-group col-md-12">
      <label for="exampleInputEmail1">Materia</label>
        <input type="text" name="nombre" class="form-control">
      <label for="exampleInputEmail1">Grupo</label>
        <select name="nivel" class="form-control">
      <option value="">--seleccione--</option>
      <?php foreach($nivel as $ni):?>
      <option value="<?php echo($ni->nombre); ?>"><?php echo $ni->nombre?></option>
      <?php endforeach;?>
    </select>
</div>


  <div class="form-group col-md-12">
     <label for="exampleInputEmail1">Profesor que imparte la materia</label>
        <select name="id_prof" class="form-control">
      <option value="">--seleccione--</option>
      <?php foreach($profesor as $profe):?>
      <option value="<?php echo($profe->id_prof); ?>"><?php echo $profe->nombres?></option>
      <?php endforeach;?>
    </select>
    </div>

          <div class="checkbox">
        <label>
         <br>
          <input type="checkbox" name="fav"> ¿Los datos son correctos?
        </label>
      </div>

  </div>
  <br>
 <button type="submit" class="btn btn-primary">Registrar</button>
</form>
    </section>